========================================================
  MEGATRON AI — WINDOWS DESKTOP SOFTWARE SUITE (v3.0)
  Full PC Hardware & System Controls Unlocked
========================================================

FEATURES INCLUDED IN THIS WINDOWS SOFTWARE SUITE:
- Master PC Volume Control: Say "volume up", "volume down", "mute", "unmute"
- System Lock: Say "lock system" or "lock screen"
- Screenshots: Say "take screenshot" to capture desktop automatically
- App Launching: Say "open notepad", "open command prompt", "open chrome"
- Win+J Global Wake Key: Press Win+J anywhere to wake Megatron instantly
- WhatsApp Desktop Automation: Direct messaging via pywhatkit
- Continuous AI Learning & Solution Finder
- Offline Local Fallback & Multi-API Integration (Gemini, Claude, GPT, Groq)

HOW TO INSTALL & RUN:
1. Extract this entire ZIP folder to any directory (e.g. C:\Megatron or D:\Megatron).
2. Double-click 'Setup_Megatron_Windows.bat'.
3. This creates a dedicated 'Megatron AI' shortcut on your Desktop with the Megatron icon.
4. Launch Megatron anytime directly from your Desktop or via 'run_megatron_windows.bat'!
